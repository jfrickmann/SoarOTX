-- 212x64/JF/CHANNELS.lua
-- Timestamp: 2019-09-14
-- Created by Jesper Frickmann

return "JF Channel Configurator ", 15, 58, 140, 0.045, 30, MIDSIZE, 0