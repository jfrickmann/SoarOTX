-- 128x64/JF/CHANNELS.lua
-- Timestamp: 2019-09-14
-- Created by Jesper Frickmann

return "Channel Config", 12, 45, 90, 0.024, 7, 0, SMLSIZE
